This plugin is to enable Custom pages and forms in moodle.

Local Pages that are of a form type will show a history underneath of all emails sent.
Pages can belong to a page or under them
Pages can only be a type of page or form

Pages created can be publicly accessed.
To restrict access to a page, set the pages permissions to match that of a specific user type.